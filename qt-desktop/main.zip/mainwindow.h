#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QStandardItemModel>
#include <QModelIndex>
#include "libtango.h"

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow {
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void onSearchTextChanged(const QString &text);
    void onSearchResultClicked(const QModelIndex &index);
    void onBackButtonClicked();

private:
    Ui::MainWindow *ui;

    TangoDB *db;
    QStandardItemModel *searchResultModel;

    void handleResult(const TangoSearchResult* result);
    void showEntryDetails(const entry* e);
    entry* currentEntry;
};

#endif // MAINWINDOW_H
