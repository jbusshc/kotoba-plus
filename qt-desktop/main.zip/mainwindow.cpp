#include "mainwindow.h"
#include "ui_mainwindow.h"

#include <QTimer>
#include <QStandardItem>
#include <QMetaObject>

static constexpr int SEARCH_DEBOUNCE_MS = 0;

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent), ui(new Ui::MainWindow),
      db(nullptr), searchResultModel(nullptr)
{
    ui->setupUi(this);

    searchResultModel = new QStandardItemModel(this);
    ui->searchResultList->setModel(searchResultModel);

    db = tango_db_open("./debug/tango.db");
    if (!db) {
        QStandardItem* item = new QStandardItem("No se pudo abrir la base de datos");
        searchResultModel->appendRow(item);
        return;
    }

    currentEntry = new entry;

    connect(ui->lineEditSearch, &QLineEdit::textChanged,
            this, &MainWindow::onSearchTextChanged);

    connect(ui->searchResultList, &QListView::clicked,
            this, &MainWindow::onSearchResultClicked);

    connect(ui->backButton, &QPushButton::clicked,
            this, &MainWindow::onBackButtonClicked);

        
    // Inicialmente mostramos la página de búsqueda
    ui->stackedWidget->setCurrentIndex(0);
}

MainWindow::~MainWindow() {
    if (db) {
        tango_db_close(db);
    }
    delete currentEntry;
    delete ui;
}

void MainWindow::onSearchTextChanged(const QString &text) {
    static QTimer *timer = nullptr;
    if (!timer) {
        timer = new QTimer(this);
        timer->setSingleShot(true);
        connect(timer, &QTimer::timeout, [this]() {
            QString currentText = ui->lineEditSearch->text();

            searchResultModel->clear();

            if (currentText.trimmed().isEmpty()) {
                return;
            }

            tango_db_text_search(db, currentText.toUtf8().constData(),
                                [](const TangoSearchResult* result, void* userdata) {
                MainWindow* self = static_cast<MainWindow*>(userdata);
                self->handleResult(result);
            }, this);
        });
    }
    timer->start(SEARCH_DEBOUNCE_MS);
}

void MainWindow::handleResult(const TangoSearchResult* result) {
    QString kanjis = QString::fromUtf8(result->kanjis).trimmed();
    QString readings = QString::fromUtf8(result->readings).trimmed();
    QString glosses = QString::fromUtf8(result->glosses).trimmed();

    QString topLine = kanjis.isEmpty() ? readings : kanjis + " " + readings;
    QString text = topLine + "\n" + glosses;

    int ent_seq = result->ent_seq; // Copy the value to avoid pointer issues

    QMetaObject::invokeMethod(this, [this, text, ent_seq]() {
        QStandardItem* item = new QStandardItem(text);
        item->setData(ent_seq, Qt::UserRole);
        item->setEditable(false);
        searchResultModel->appendRow(item);
    }, Qt::QueuedConnection);
}

void MainWindow::onSearchResultClicked(const QModelIndex &index) {
    if (!index.isValid()) return;

    int ent_seq = index.data(Qt::UserRole).toInt();
    qDebug() << "Clicked ent_seq:" << ent_seq;

    memset(currentEntry, 0, sizeof(entry));

    // Llama pasando el puntero currentEntry para que se llene ahí
    tango_db_id_search(db, ent_seq, currentEntry, [](const entry* e, void* userdata) {
        MainWindow* self = static_cast<MainWindow*>(userdata);
        // Aquí e == self->currentEntry, que ya contiene los datos
        QMetaObject::invokeMethod(self, [self]() {
            self->showEntryDetails(self->currentEntry);
        }, Qt::QueuedConnection);
    }, this);

    // Cambiar a la página detalles (índice 1)
    ui->stackedWidget->setCurrentIndex(1);

    // Deseleccionar para que no quede marcado
    ui->searchResultList->clearSelection();
}



void MainWindow::showEntryDetails(const entry* e) {
    qDebug() << "Mostrando detalles para entry:" << e->ent_seq;
    if (!e) return;

    qDebug() << "not nullptr:" << e->ent_seq;
    QString detailText;

    // Arma el texto con todo el detalle
    detailText += QString("Entry ID: %1\n\n").arg(e->ent_seq);

    detailText += "Kanjis:\n";
    for (int i = 0; i < e->k_elements_count; i++) {
        detailText += QString(" - %1\n").arg(QString::fromUtf8(e->k_elements[i].keb));
    }

    detailText += "\nReadings:\n";
    for (int i = 0; i < e->r_elements_count; i++) {
        detailText += QString(" - %1\n").arg(QString::fromUtf8(e->r_elements[i].reb));
    }

    detailText += "\nSenses:\n";
    qDebug() << "Senses count:" << e->senses_count;
    for (int i = 0; i < e->senses_count; i++) {
        const sense &s = e->senses[i];
        qDebug() << "Sense" << i << "has" << s.gloss_count << "glosses";
        for (int j = 0; j < s.gloss_count; j++) {
            qDebug() << "Gloss" << j << ":" << QString::fromUtf8(s.gloss[j]);
            detailText += QString(" - %1\n").arg(QString::fromUtf8(s.gloss[j]));
        }
        detailText += "\n";
    }

    // Poner el texto en el QTextEdit de la página detalles
    ui->detailTextEdit->setText(detailText);

    // Cambiar a la página detalles (índice 1)
    ui->stackedWidget->setCurrentIndex(1);
}


void MainWindow::onBackButtonClicked() {
    // Volver a la página búsqueda
    ui->stackedWidget->setCurrentIndex(0);
}
